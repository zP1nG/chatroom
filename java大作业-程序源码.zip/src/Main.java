
public class Main {
	public static void main(String args[]) {
		PassWordWin a = new PassWordWin();
		a.show_surface();
		a.getinfo();
	}
}
